package swaggerApiCall;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
public class SwaggerApiCall {
	
	public static final String BASE_URL = "https://bpdts-test-app.herokuapp.com/";

	public static void main(String[] args) {
		 try {
			SwaggerApiCall.MyCityRequest();
			SwaggerApiCall.MyUserRequest();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 }
	public static void MyCityRequest() throws IOException {
		
	    URL urlForGetRequest = createRequestURL("city", "London");   //new URL("https://bpdts-test-app.herokuapp.com/city/London/users");
	    String readLine = null;
	    HttpURLConnection connection = (HttpURLConnection) urlForGetRequest.openConnection();
	    connection.setRequestMethod("GET");
	    connection.setRequestProperty("Content-Type", "application/json; utf-8");
	    connection.setRequestProperty("Accept", "application/json");
	    int responseCode = connection.getResponseCode();
	    if (responseCode == HttpURLConnection.HTTP_OK) {
	        BufferedReader in = new BufferedReader(
	            new InputStreamReader(connection.getInputStream()));
	        StringBuffer response = new StringBuffer();
	        while ((readLine = in .readLine()) != null) {
	            response.append(readLine);
	        } in .close();
	        // print result
	        System.out.println("JSON String Result " + response.toString());
	        //GetAndPost.POSTRequest(response.toString());
	    } else {
	        System.out.println("GET NOT WORKED");
	    }
	}
	public static void MyUserRequest() throws IOException {
		
	    URL urlForGetRequest = createRequestURL();   //new URL("https://bpdts-test-app.herokuapp.com/users");
	    String readLine = null;
	    HttpURLConnection connection = (HttpURLConnection) urlForGetRequest.openConnection();
	    connection.setRequestMethod("GET");
	    connection.setRequestProperty("Content-Type", "application/json; utf-8");
	    connection.setRequestProperty("Accept", "application/json");
	    int responseCode = connection.getResponseCode();
	    if (responseCode == HttpURLConnection.HTTP_OK) {
	        BufferedReader in = new BufferedReader(
	            new InputStreamReader(connection.getInputStream()));
	        StringBuffer response = new StringBuffer();
	        while ((readLine = in .readLine()) != null) {
	            response.append(readLine);
	        } in .close();
	        // print result
	        System.out.println("JSON String Result " + response.toString());
	        //GetAndPost.POSTRequest(response.toString());
	    } else {
	        System.out.println("GET NOT WORKED");
	    }
	}
	private static URL createRequestURL(String parameterName, String parameter) {
		StringBuilder urlParameters = new StringBuilder();
		urlParameters.append(BASE_URL);
		urlParameters.append(parameterName);
		urlParameters.append("/");
		urlParameters.append(parameter);
		urlParameters.append("/users");
		
		URL requestURL = null;
		try {
			requestURL = new URL(urlParameters.toString() );
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("requestURL " + urlParameters);
		return requestURL;
	}
	private static URL createRequestURL() {
		StringBuilder urlParameters = new StringBuilder();
		urlParameters.append(BASE_URL);
		urlParameters.append("users");
		
		URL requestURL = null;
		try {
			requestURL = new URL(urlParameters.toString() );
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("requestURL " + urlParameters);
	
		return requestURL;
	}

} // end of SwaggerApiCall class
